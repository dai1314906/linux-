# Source Code of Linux 0.0.1

[中文版? 点击这里](README.md)

## What is it? 
This is the source code of Linux 0.0.1, the first version of Linux. 

Linus forgot this version and this is his friend's. 

## Why Linux 0.0.1? 

Now, (2020) Linux source code has million lines. Linux 0.0.1 is Simpler than it. 

## How can I use it? 

There was a [Makefile](Makefile). You must install GCC-ARM on your Computer (because Linux use ARM Assembly, not AT&T). 

Then, type make (or mingw32-make) to terminal, Compiler is starting. It'll create a Image File and write data to it likes disk. 

Finally, burn the Image File to your disk (or other media), and then restart your Computer. Linux 0.0.1 will start. 
